#include <iostream>
#include <iomanip>
#include <limits>
#include <string>
#include <vector>

using namespace std;

struct Course {
    string name;
    double grade;
    double credits;
};

double readPositiveNumber(const string& prompt) {
    double value;
    while (true) {
        cout << prompt;
        if (cin >> value && value > 0) {
            return value;
        }

        cout << "Invalid input. Please enter a number greater than 0.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

double readNonNegativeNumber(const string& prompt) {
    double value;
    while (true) {
        cout << prompt;
        if (cin >> value && value >= 0) {
            return value;
        }

        cout << "Invalid input. Please enter 0 or a positive number.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
}

int main() {
    cout << "=====================================\n";
    cout << "       CGPA CALCULATOR (C++)\n";
    cout << "=====================================\n\n";

    int courseCount;
    while (true) {
        cout << "Enter the number of courses: ";
        if (cin >> courseCount && courseCount > 0) {
            break;
        }

        cout << "Please enter a valid positive integer.\n";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    vector<Course> courses;
    courses.reserve(courseCount);

    double totalCredits = 0.0;
    double totalGradePoints = 0.0;

    for (int i = 0; i < courseCount; ++i) {
        Course course;

        cout << "\nCourse " << (i + 1) << '\n';
        cout << "Enter course name (one word, e.g. Mathematics): ";
        cin >> course.name;

        course.grade = readNonNegativeNumber("Enter grade point (e.g. 0 to 10): ");
        course.credits = readPositiveNumber("Enter credit hours: ");

        courses.push_back(course);
        totalCredits += course.credits;
        totalGradePoints += course.grade * course.credits;
    }

    const double semesterGPA = totalGradePoints / totalCredits;

    cout << "\n=====================================\n";
    cout << "           COURSE SUMMARY\n";
    cout << "=====================================\n";
    cout << left << setw(22) << "Course"
         << right << setw(12) << "Grade"
         << setw(14) << "Credits"
         << setw(18) << "Grade Points" << '\n';
    cout << string(66, '-') << '\n';

    cout << fixed << setprecision(2);
    for (const Course& course : courses) {
        cout << left << setw(22) << course.name
             << right << setw(12) << course.grade
             << setw(14) << course.credits
             << setw(18) << (course.grade * course.credits) << '\n';
    }

    cout << string(66, '-') << '\n';
    cout << left << setw(22) << "Total"
         << right << setw(12) << "-"
         << setw(14) << totalCredits
         << setw(18) << totalGradePoints << '\n';

    cout << "\nSemester GPA: " << semesterGPA << '\n';

    cout << "\nDo you have previous semester results? (y/n): ";
    char choice;
    cin >> choice;

    double cgpa = semesterGPA;
    if (choice == 'y' || choice == 'Y') {
        const double previousCGPA =
            readNonNegativeNumber("Enter previous CGPA: ");
        const double previousCredits =
            readNonNegativeNumber("Enter total credits completed previously: ");

        if (previousCredits + totalCredits > 0) {
            cgpa = (previousCGPA * previousCredits + totalGradePoints) /
                   (previousCredits + totalCredits);
        }
    }

    cout << "\n=====================================\n";
    cout << "Final CGPA: " << cgpa << '\n';
    cout << "=====================================\n";

    return 0;
}
