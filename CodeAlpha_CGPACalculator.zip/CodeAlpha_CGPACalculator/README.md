# CodeAlpha_CGPACalculator

A beginner-friendly C++ console application that calculates semester GPA and cumulative CGPA using course grade points and credit hours.

## Features
- Accepts the number of courses.
- Collects each course name, grade point, and credit hours.
- Displays a course-wise summary and total grade points.
- Calculates semester GPA using a credit-weighted average.
- Calculates cumulative CGPA when previous CGPA and completed credits are supplied.
- Includes basic validation for numeric inputs.

## Formula

Semester GPA:

`Semester GPA = Sum(grade point × credit hours) / Sum(credit hours)`

Cumulative CGPA:

`CGPA = (Previous CGPA × Previous Credits + Current Grade Points) / (Previous Credits + Current Credits)`

If no previous semester results are entered, the current semester GPA is shown as CGPA.

## Compile and run

### Using g++
```bash
g++ main.cpp -o cgpa
./cgpa
```

On Windows:
```bash
g++ main.cpp -o cgpa.exe
cgpa.exe
```

## Example
For three courses:
- Mathematics: grade 9, credits 4
- Programming: grade 8, credits 3
- Physics: grade 7, credits 3

Total grade points = `9×4 + 8×3 + 7×3 = 79`  
Total credits = `10`  
Semester GPA = `79 / 10 = 7.90`

## Note
This project assumes grade points are entered on a consistent scale (for example, 0–10). Use your institution's grading scale. Course names are entered as one word in this simple console version.

## GitHub repository name
`CodeAlpha_CGPACalculator`
